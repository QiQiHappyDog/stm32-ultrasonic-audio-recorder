#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

void write_wav_header(FILE *f, int samples, uint32_t sample_rate);

int main(int argc, char *argv[]) {

    /* argv[1] = sample rate (Hz)
     * argv[2] = input  raw file path
     * argv[3] = output wav file path                                      */

    uint32_t sample_rate = (argc > 1) ? (uint32_t)atoi(argv[1]) : 44444;
    const char *in_path  = (argc > 2) ? argv[2] : "raw_audio.dat";
    const char *out_path = (argc > 3) ? argv[3] : "output.wav";

    if (sample_rate < 8000 || sample_rate > 200000) {
        fprintf(stderr, "Invalid sample rate %u, using 44444\n", sample_rate);
        sample_rate = 44444;
    }

    FILE *in  = fopen(in_path,  "rb");
    FILE *out = fopen(out_path, "wb");
    if (!in || !out) {
        fprintf(stderr, "Error opening files\n");
        return 1;
    }

    write_wav_header(out, 0, sample_rate);   /* placeholder — rewritten at end */

    uint16_t adc_val;
    int count = 0;

    while (fread(&adc_val, 2, 1, in) == 1) {
        int32_t sample = (adc_val & 0x0FFF) - 2048;
        int16_t pcm    = (int16_t)(sample * 16);
        fwrite(&pcm, 2, 1, out);
        count++;
    }

    /* Rewrite header with final sample count */
    fseek(out, 0, SEEK_SET);
    write_wav_header(out, count, sample_rate);

    fclose(in);
    fclose(out);

    printf("Done: %d samples @ %u Hz -> %s\n", count, sample_rate, out_path);
    return 0;
}

void write_wav_header(FILE *f, int samples, uint32_t s_rate) {
    uint32_t d_sz   = samples * 2;
    uint32_t c_sz   = 36 + d_sz;
    uint32_t b_rate = s_rate * 2;
    uint16_t fmt    = 1, ch = 1, bit = 16, algn = 2;
    uint32_t s1     = 16;

    fwrite("RIFF", 1, 4, f); fwrite(&c_sz,   4, 1, f);
    fwrite("WAVE", 1, 4, f); fwrite("fmt ",  1, 4, f);
    fwrite(&s1,    4, 1, f); fwrite(&fmt,    2, 1, f);
    fwrite(&ch,    2, 1, f); fwrite(&s_rate, 4, 1, f);
    fwrite(&b_rate,4, 1, f); fwrite(&algn,   2, 1, f);
    fwrite(&bit,   2, 1, f); fwrite("data",  1, 4, f);
    fwrite(&d_sz,  4, 1, f);
}