import serial
import numpy as np
import time
import matplotlib.pyplot as plt
import wave
import os
import csv
import subprocess
from scipy.signal import butter, sosfilt

PORT       = 'COM3'
BAUD       = 921600
FS_DEFAULT = 44444
SAVE_DIR   = "recordings"

if not os.path.exists(SAVE_DIR):
    os.makedirs(SAVE_DIR)

# Compile convert_to_wav.c once at startup
CONVERTER_SRC = "convert_to_wav.c"
CONVERTER_EXE = "convert_to_wav.exe" if os.name == 'nt' else "./convert_to_wav"

def compile_converter():
    if not os.path.exists(CONVERTER_SRC):
        print(f"  [WARN] {CONVERTER_SRC} not found — WAV conversion unavailable.")
        return False
    out_flag = CONVERTER_EXE if os.name == 'nt' else "convert_to_wav"
    result = subprocess.run(
        ["gcc", CONVERTER_SRC, "-o", out_flag],
        capture_output=True, text=True
    )
    if result.returncode != 0:
        print(f"  [WARN] Compiler error:\n{result.stderr}")
        return False
    print(f"  Compiled {CONVERTER_SRC} successfully.")
    return True

CONVERTER_READY = compile_converter()


# ---------------------------------------------------------------------------
# realign_to_12bit
# ---------------------------------------------------------------------------
def realign_to_12bit(raw_bytes):
    aligned = bytearray()
    i = 0
    while i <= len(raw_bytes) - 2:
        word = raw_bytes[i] | (raw_bytes[i + 1] << 8)
        if word <= 0x0FFF:
            aligned.append(raw_bytes[i])
            aligned.append(raw_bytes[i + 1])
            i += 2
        else:
            i += 1
    return bytes(aligned)


# ---------------------------------------------------------------------------
# remove_spikes
# ---------------------------------------------------------------------------
def remove_spikes(samples_float, delta_threshold=600.0):
    cleaned = samples_float.copy()
    for i in range(1, len(cleaned)):
        if abs(cleaned[i] - cleaned[i - 1]) > delta_threshold:
            cleaned[i] = cleaned[i - 1]
    return cleaned


# ---------------------------------------------------------------------------
# highpass_filter
# ---------------------------------------------------------------------------
def highpass_filter(samples_float, fs, cutoff=80.0, order=4):
    nyq = fs / 2.0
    sos = butter(order, cutoff / nyq, btype='high', output='sos')
    return sosfilt(sos, samples_float)


# ---------------------------------------------------------------------------
# process_data
#   raw_bytes    : bytearray of 16-bit little-endian samples
#   name         : base filename
#   hw_fs        : sample rate from STM32 hardware registers
#   target_secs  : if > 0, trim (or pad) samples to exactly this duration
# ---------------------------------------------------------------------------
def process_data(raw_bytes, name, hw_fs, target_secs=0):

    if len(raw_bytes) < 2000:
        print(f"  [WARN] Data too short ({len(raw_bytes)} bytes). Skipping.")
        return

    # Stage 1: realign
    aligned = realign_to_12bit(raw_bytes)
    if len(aligned) % 2 != 0:
        aligned = aligned[:-1]
    if len(aligned) < 2000:
        print(f"  [WARN] Too few valid samples after realignment. Skipping.")
        return

    raw_samples = np.frombuffer(aligned, dtype='<u2') & 0x0FFF

    # Trim or pad to target duration
    if target_secs > 0:
        target_samples = int(target_secs * hw_fs)
        if len(raw_samples) >= target_samples:
            # Trim — we have enough, just cut to exact length
            raw_samples = raw_samples[:target_samples]
        else:
            # Still not enough even with extra recording time — pad with silence
            pad_count   = target_samples - len(raw_samples)
            padding     = np.full(pad_count, 2048, dtype=np.uint16)
            raw_samples = np.concatenate([raw_samples, padding])

    duration = len(raw_samples) / hw_fs

    print(f"  Duration      : {duration:.3f} s")

    # Stage 2: centre
    centred = raw_samples.astype(np.float64) - 2048.0

    # Stage 3: spike removal
    despike = remove_spikes(centred, delta_threshold=600.0)

    # Stage 4: high-pass
    filtered = highpass_filter(despike, fs=hw_fs)

    filtered_clipped  = np.clip(filtered, -2048.0, 2047.0)
    filtered_unsigned = (filtered_clipped + 2048.0).astype(np.uint16)

    # CSV
    csv_path = os.path.join(SAVE_DIR, f"{name}.csv")
    with open(csv_path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["Sample Rate (Hz)", hw_fs])
        for s in filtered_unsigned:
            writer.writerow([s])
    print(f"  Saved CSV : {csv_path}")

    # PNG
    total_samples = len(filtered_unsigned)
    step          = max(1, total_samples // 200000)
    plot_samples  = filtered_unsigned[::step]
    plot_t        = np.arange(len(plot_samples)) * step / hw_fs

    fig, ax = plt.subplots(figsize=(14, 4))
    ax.plot(plot_t, plot_samples, lw=0.4, color='steelblue')
    ax.set_title(
        f"Audio Waveform  —  {name}\n"
        f"Duration: {duration:.3f} s"
    )
    ax.set_xlabel("Time (s)")
    ax.set_ylabel("ADC Value (12-bit,  0 – 4095)")
    ax.set_xlim([0, duration])
    ax.set_ylim([0, 4095])
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    png_path = os.path.join(SAVE_DIR, f"{name}.png")
    fig.savefig(png_path, dpi=150)
    plt.close(fig)
    print(f"  Saved PNG : {png_path}")

    # WAV via C converter — unique filenames per recording
    wav_path = os.path.join(SAVE_DIR, f"{name}.wav")
    raw_dat  = os.path.join(SAVE_DIR, f"{name}_raw.dat")

    with open(raw_dat, 'wb') as f:
        f.write(filtered_unsigned.astype('<u2').tobytes())

    if CONVERTER_READY:
        result = subprocess.run(
            [CONVERTER_EXE, str(hw_fs), raw_dat, wav_path],
            capture_output=True, text=True
        )
        if result.returncode == 0:
            print(f"  Saved WAV : {wav_path}")
        else:
            print(f"  [WARN] C converter failed: {result.stderr}")
            _save_wav_python(filtered_clipped, wav_path, hw_fs)
    else:
        _save_wav_python(filtered_clipped, wav_path, hw_fs)

    if os.path.exists(raw_dat):
        os.remove(raw_dat)


def _save_wav_python(filtered_clipped, wav_path, hw_fs):
    scaled = (filtered_clipped * 16.0).clip(-32768, 32767).astype(np.int16)
    with wave.open(wav_path, 'wb') as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(int(hw_fs))
        wf.writeframes(scaled.tobytes())
    print(f"  Saved WAV : {wav_path}  (Python fallback)")


# ---------------------------------------------------------------------------
# parse_fs_from_start_packet  AA 01 LL MM HH BB
# ---------------------------------------------------------------------------
def parse_fs_from_start_packet(buf, i):
    if i + 5 < len(buf) and buf[i + 5] == 0xBB:
        fs = buf[i + 2] | (buf[i + 3] << 8) | (buf[i + 4] << 16)
        if 10000 < fs < 200000:
            return fs, 6
    return None, None


# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------
def main():

    ser = serial.Serial(PORT, BAUD, timeout=0.01)
    print(f"Serial connected  {PORT}  @  {BAUD} baud")

    hw_fs = FS_DEFAULT

    try:
        while True:

            print("\n========================================")
            print("  AUDIO RECORDER — Main Menu")
            print("========================================")
            print("  1. Manual Recording Mode")
            print("  2. Auto (Distance Trigger) Mode")
            print("  3. Exit")
            print("----------------------------------------")

            choice = input("  Select: ").strip()

            # ================================================================
            # MODE 1 — MANUAL RECORDING
            # ================================================================
            if choice == '1':

                t = float(input("  Recording time (seconds): ") or 5.0)

                ser.write(b'\x01')
                ser.reset_input_buffer()

                audio_data = bytearray()
                start = time.time()

                # Record t + 0.5s to absorb Python/serial overhead and
                # realignment losses. Output is trimmed to exactly t seconds.
                while time.time() - start < t + 1:
                    if ser.in_waiting:
                        audio_data.extend(ser.read(ser.in_waiting))

                process_data(audio_data, f"manual_{int(time.time())}", hw_fs,
                             target_secs=t)

            # ================================================================
            # MODE 2 — AUTO (DISTANCE TRIGGER)
            # ================================================================
            elif choice == '2':

                print("\n  Trigger distance settings")
                raw = input("  Enter trigger distance in cm [press Enter for 10]: ").strip()

                if raw == '':
                    start_cm = 10
                else:
                    try:
                        start_cm = int(raw)
                        if start_cm < 2 or start_cm > 127:
                            print("  Out of range (2–127) — using default 10 cm.")
                            start_cm = 10
                    except ValueError:
                        print("  Invalid input — using default 10 cm.")
                        start_cm = 10

                # Stop threshold = same as start threshold
                stop_cm = start_cm

                threshold_byte = max(start_cm, 16)
                ser.write(bytes([threshold_byte]))
                time.sleep(0.05)

                ser.write(b'\x02')
                ser.reset_input_buffer()

                print(f"\n  Bring hand within {start_cm} cm to START.")
                print(f"  Move hand beyond  {stop_cm} cm to STOP.")
                print("  Press Ctrl+C to return to the main menu.\n")

                raw_buffer     = bytearray()
                audio_data     = bytearray()
                is_recording   = False
                last_data_time = time.time()

                try:
                    while True:

                        if ser.in_waiting:
                            raw_buffer.extend(ser.read(ser.in_waiting))
                            last_data_time = time.time()

                        i = 0
                        while i < len(raw_buffer):

                            if i > len(raw_buffer) - 3:
                                break

                            if raw_buffer[i] == 0xAA:
                                cmd = raw_buffer[i + 1]

                                if cmd == 0x01:
                                    if i + 5 >= len(raw_buffer):
                                        break
                                    fs, pkt_len = parse_fs_from_start_packet(raw_buffer, i)
                                    if fs is not None:
                                        hw_fs = fs
                                        print(f"  START — recording ... (FS={hw_fs} Hz)")
                                    else:
                                        pkt_len = 6
                                        print(f"  START — recording ...")
                                    is_recording = True
                                    audio_data   = bytearray()
                                    i += pkt_len
                                    continue

                                elif cmd == 0x02 and raw_buffer[i + 2] == 0xBB:
                                    print("  STOP")
                                    is_recording = False
                                    if len(audio_data) > 0:
                                        fname = f"auto_{int(time.time())}"
                                        # No padding for auto mode — duration is natural
                                        process_data(audio_data, fname, hw_fs)
                                    i += 3
                                    continue

                            if is_recording:
                                audio_data.append(raw_buffer[i])

                            i += 1

                        if i > 0:
                            raw_buffer = raw_buffer[i:]

                        if is_recording and (time.time() - last_data_time > 1.0):
                            print("  [WARN] Timeout — forcing STOP")
                            is_recording = False
                            if len(audio_data) > 0:
                                fname = f"timeout_{int(time.time())}"
                                print(f"  Processing '{fname}' ...")
                                process_data(audio_data, fname, hw_fs)
                            audio_data = bytearray()

                        time.sleep(0.001)

                except KeyboardInterrupt:
                    print("\n  Returning to main menu ...")

            elif choice == '3':
                print("  Goodbye.")
                break

            else:
                print("  Invalid selection — please enter 1, 2, or 3.")

    finally:
        ser.close()
        print("Serial port closed.")


if __name__ == "__main__":
    main()